// Volume
const bgAudio = document.getElementById('bg-audio');
        bgAudio.volume = 0.1;

// Scroll to vid
document.querySelector('a[href="#showcase"]').addEventListener('click', function (e) {
    e.preventDefault();
    const target = document.getElementById('showcase');
    const targetOffsetTop = target.offsetTop;
    const initialScroll = window.pageYOffset;
    const distance = targetOffsetTop - initialScroll;
    const duration = 500; // Adjust duration as needed

    function smoothScroll(timestamp) {
        const elapsed = timestamp - startTime;
        const progress = Math.min(elapsed / duration, 1);
        window.scrollTo(0, initialScroll + distance * progress);

        if (elapsed < duration) {
            requestAnimationFrame(smoothScroll);
        }
    }

    const startTime = performance.now();
    requestAnimationFrame(smoothScroll);
});

document.addEventListener('DOMContentLoaded', function() {
    const links = document.querySelectorAll('a'); // Get all anchor links

    // Add event listeners to all anchor links
    links.forEach(link => {
        link.addEventListener('click', function(e) {
            e.preventDefault(); // Prevent the default action of clicking the link

            const href = this.getAttribute('href'); // Get the href attribute of the clicked link
            const mainContent = document.querySelector('main'); // Get the main content area

            // Add a class to trigger the transition effect
            mainContent.classList.add('page-transition-out');

            // After a short delay, change the page URL
            setTimeout(() => {
                window.location.href = href;
            }, 500); // Adjust timing as needed
        });
    });
});
