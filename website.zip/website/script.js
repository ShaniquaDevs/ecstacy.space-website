// Volume
const bgAudio = document.getElementById('bg-audio');
        bgAudio.volume = 0.1;

// Scroll to vid
document.querySelector('a[href="#showcase"]').addEventListener('click', function (e) {
    e.preventDefault();
    const target = document.getElementById('showcase');
    const targetOffsetTop = target.offsetTop;
    const initialScroll = window.pageYOffset;
    const distance = targetOffsetTop - initialScroll;
    const duration = 500; // Adjust duration as needed

    function smoothScroll(timestamp) {
        const elapsed = timestamp - startTime;
        const progress = Math.min(elapsed / duration, 1);
        window.scrollTo(0, initialScroll + distance * progress);

        if (elapsed < duration) {
            requestAnimationFrame(smoothScroll);
        }
    }

    const startTime = performance.now();
    requestAnimationFrame(smoothScroll);
});